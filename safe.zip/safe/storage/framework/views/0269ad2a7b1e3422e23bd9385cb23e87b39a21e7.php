<?php 

?>


<!--  BEGIN CREATE USER PART  -->
<br>

<div id="basic" class="col-lg-12 layout-spacing">
    <div class="widget-header">
        <div class="row">
            <div class="col-xl-12 col-md-12 col-sm-12 col-12">
                <div id="btn-main" class="row">
                    <button type="button" onclick="showFormData()" class="btn btn-success btn-blck mt-5">New
                        Admin</button>
                </div>
            </div>
        </div>
    </div>
</div>

<div id="form1" class="col-lg-12 layout-spacing">
    <div class="statbox widget box box-shadow">
        <div class="widget-header">
            <div class="row">
                <div class="col-xl-12 col-md-12 col-sm-12 col-12">
                    <h5>Create New User</h5>
                </div>
            </div>
        </div>
        <div class="widget-content widget-content-area">
            <form id="user_form" role="form" method="post" enctype="multipart/form-data" action="/saveuserdetails">
                <?php echo e(csrf_field()); ?>

                <div class="row">
                    <div class="form-group col-md-6">
                        <label for="full_name">Full Name</label>
                        <input type="text" class="form-control" id="txt_full_name" name="txt_full_name">
                    </div>

                    <div class="form-group col-md-6">
                        <label for="email">Email</label>
                        <input type="email" class="form-control" id="txt_email" name="txt_email">
                    </div>
                </div>

                <div class="row">
                    <div class="form-group col-md-6">
                        <label for="password">Password</label>
                        <input type="password" class="form-control" id="txt_password" name="txt_password">
                    </div>

                    <div class="form-group col-md-6">
                        <label for="conform_password">Conform Password</label>
                        <input type="password" class="form-control" id="txt_confirm_password"
                            name="txt_confirm_password">
                    </div>

                    <div class="form-group col-md-6">
                        <label for="conform_password">Profile Pic</label>
                        <input type="file" class="form-control" name="txt_propic" id="txt_propic"
                            name="txt_confirm_password">
                    </div>
                </div>

                <button class="btn btn-primary mb-2 mr-2" type="submit">Submit</button>
                <button class="btn btn-primary mb-2" type="reset">Clear</button>
            </form>
        </div>
    </div>
</div>

<!--  END CONTENT PART  -->

<script>
    // showFormData 
    function showFormData() {
        // show form when click
        $('#form1').show();
        // save record function call when form show
        $('#txt_data').val('SAVE');

        // create jquery content for hide btn for the main btn  btn-main
        let btnData = '';
        btnData += '<button type="button" onclick="HideFormData()" class="btn btn-info btn-blck mt-5">Hide-Form</button>';
        btnData += '<br>';
        $('#btn-main').html(btnData);

    }

    // this is for when form is hide btn click for show form
    function HideFormData() {
        $('#form1').hide();
        // this is for when page relaord all fields value keep empty
        $('#txt_first_name').val('');
        $('#txt_last_name').val('');
        $('#txt_email').val('');
        $('#txt_user_password').val('');
        $('#txt_profile').val('');
        $('#txt_contact').val('');

        let btnData = '';
        btnData += '<button type="button" onclick="showFormData()" class="btn btn-info btn-blck mt-5">Hide-Form</button>';
        $('#btn-main').html(btnData);

    }
</script>

<script>
    $(document).ready(function() {
            $('#form1').hide();

            // this is for when page relaord all fields value keep empty
           $('#txt_full_name').val('');
            $('#txt_email').val('');
            $('#txt_password').val('');
            $('#txt_confirm_password').val('');
            $('#txt_propic').val('');

            $("#user_form").validate({
            ignore: [],
            rules: {
                txt_full_name: {
                        required: true,
                    },
                    txt_email: {
                        required: true,
                        email: true
                    },
                    txt_password: {
                        required: true,
                       
                    },
                    txt_confirm_password: {
                        required: true,
                        equalTo: '#txt_password'
                    },
                    txt_propic: {
                        required: true,
                    }

                },
                messages: {
                    txt_full_name: "fullname is required!",
                    txt_password: "password is Required!",
                    txt_email: {
                        required: "Email Address is Required!",
                        email: "Please enter a valid email address!"
                    },
                    txt_confirm_password: {
                        required: "confirm is Required!",
                    },
                    txt_propic: {
                        required: "User Profile Image is Required!",
                    } 
                },
            
              
        });
      });

</script><?php /**PATH C:\xampp\htdocs\new_laravel\safymade - Copy\sefy\resources\views/Admin/pageadmin.blade.php ENDPATH**/ ?>