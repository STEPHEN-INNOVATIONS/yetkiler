<script src="<?php echo e(asset('FrontEnd/bootstrap/js/popper.min.js')); ?>"></script>
<script src="<?php echo e(asset('FrontEnd/bootstrap/js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('FrontEnd/plugins/perfect-scrollbar/perfect-scrollbar.min.js')); ?>"></script>
<script src="<?php echo e(asset('FrontEnd/assets/js/app.js')); ?>"></script>
<script>
$(document).ready(function() {
    App.init();
});
</script>
<script src="<?php echo e(asset('FrontEnd/assets/js/custom.js')); ?>"></script>
<!-- END GLOBAL MANDATORY SCRIPTS -->

<!-- BEGIN PAGE LEVEL PLUGINS/CUSTOM SCRIPTS -->
<script src="<?php echo e(asset('FrontEnd/plugins/apex/apexcharts.min.js')); ?>"></script>
<script src="<?php echo e(asset('FrontEnd/assets/js/dashboard/dash_1.js')); ?>"></script>


<!-- jquery validations  this validations links are required-->
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.2/jquery.validate.min.js"></script>
<script
    src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validation-unobtrusive/3.2.11/jquery.validate.unobtrusive.min.js">
</script><?php /**PATH C:\xampp\htdocs\new_laravel\safymade - Copy\sefy\resources\views/Backend/Template/script.blade.php ENDPATH**/ ?>