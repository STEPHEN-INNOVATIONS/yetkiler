<script src="<?php echo e(asset('FrontEnd/assets/js/libs/jquery-3.1.1.min.js')); ?>"></script>
<script src="<?php echo e(asset('FrontEnd/bootstrap/js/popper.min.js')); ?>"></script>
<script src="<?php echo e(asset('FrontEnd/bootstrap/js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('FrontEnd/plugins/perfect-scrollbar/perfect-scrollbar.min.js')); ?>"></script>
<script src="<?php echo e(asset('FrontEnd/assets/js/app.js')); ?>"></script>
<script>
$(document).ready(function() {
    App.init();
});
</script>
<script src="<?php echo e(asset('FrontEnd/assets/js/custom.js')); ?>"></script>
<!-- END GLOBAL MANDATORY SCRIPTS -->

<!-- BEGIN PAGE LEVEL PLUGINS/CUSTOM SCRIPTS -->
<script src="<?php echo e(asset('FrontEnd/plugins/apex/apexcharts.min.js')); ?>"></script>
<script src="<?php echo e(asset('FrontEnd/assets/js/dashboard/dash_1.js')); ?>"></script><?php /**PATH C:\xampp\htdocs\new_laravel\safymade\sefy\resources\views/Backend/Template/script.blade.php ENDPATH**/ ?>